import java.io.FileNotFoundException;
import java.util.ArrayList;

class Main
{
    //I dont think this works.
    Main() throws FileNotFoundException
    {
        System.out.println("No file found");
    }

    public static void main(String[] args) throws FileNotFoundException
    {
        Timer myTimer = new Timer();
        //just to note you may need to mess with the filenames to get it to find it because im using IntelliJ
        //it for some reason only likes this file path so you have my benevolent authority to modify this here code
        ArrayList<DataEntry> lastNamesDataset = Dataset.getDataset("src/facebook-lastnames-withcount.txt");
        ArrayList<DataEntry> firstNamesDataset = Dataset.getDataset("src/facebook-firstnames-withcount.txt");

        //ArrayList<DataEntry> lastNamesDataset = Dataset.getDataset("src/facebook-lastnames-withcount.txt");
        //ArrayList<DataEntry> firstNamesDataset = Dataset.getDataset("src/facebook-firstnames-withcount.txt");

        //Sort.selectionSort(lastNamesDataset);
        //Sort.selectionSort(firstNamesDataset);

        for (int i = 0; i < 99999; i++)
        {
            System.out.println(i + "  " + firstNamesDataset.get(i));
        }
        System.out.println("---------------------------------------------------------------------------");

        for (int i = 0; i < 99999; i++)
        {
            System.out.println(lastNamesDataset.get(i));
        }
        //myTimer.startTimer();
        //System.out.println(firstNamesDataset.get(Search.linearSearch(firstNamesDataset, "mike")));
        //System.out.println(firstNamesDataset.get(Search.binarySearch(firstNamesDataset, "mike")));
        //myTimer.endTimer();
    }
}