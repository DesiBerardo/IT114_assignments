class DataEntry
{
    int count;
    String name;
}